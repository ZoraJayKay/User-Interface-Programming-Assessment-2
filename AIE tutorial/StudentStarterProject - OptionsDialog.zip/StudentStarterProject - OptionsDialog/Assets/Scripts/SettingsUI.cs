﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SettingsUI : MonoBehaviour
{
    public Settings settings;

    public FloatEditor musicVolume;
    public FloatEditor fxVolume;

    public Toggle stereo;

    private void Start()
    {
    }

}
